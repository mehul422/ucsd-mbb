# ucsd mbb analysis > 2025-05-26 8:42pm
https://universe.roboflow.com/ucsd-mbb/ucsd-mbb-analysis

Provided by a Roboflow user
License: CC BY 4.0

